package com.smartsleeper.backend;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/passengers")
public class PassengerController {


private final PassengerRepository passengerRepository;

public PassengerController(PassengerRepository passengerRepository) {
    this.passengerRepository = passengerRepository;
}

@PostMapping
public Passenger savePassenger(@RequestBody Passenger passenger) {
    return passengerRepository.save(passenger);
}

@GetMapping
public List<Passenger> getAllPassengers() {
    return passengerRepository.findAll();
}


}
