package com.smartsleeper.backend;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "passengers")
public class Passenger {


@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;

private String passengerName;
private String bookingId;
private String destination;

public Passenger() {
}

public Long getId() {
    return id;
}

public void setId(Long id) {
    this.id = id;
}

public String getPassengerName() {
    return passengerName;
}

public void setPassengerName(String passengerName) {
    this.passengerName = passengerName;
}

public String getBookingId() {
    return bookingId;
}

public void setBookingId(String bookingId) {
    this.bookingId = bookingId;
}

public String getDestination() {
    return destination;
}

public void setDestination(String destination) {
    this.destination = destination;
}


}
