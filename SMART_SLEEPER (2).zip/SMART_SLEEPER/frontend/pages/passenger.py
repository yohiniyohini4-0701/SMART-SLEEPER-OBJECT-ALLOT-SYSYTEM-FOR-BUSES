import streamlit as st

st.set_page_config(
    page_title="Passenger Login | Smart Sleeper",
    page_icon="🧳",
    layout="centered"
)

st.title("🧳 Passenger Login")
st.write("Welcome to Smart Sleeper!")

st.divider()

with st.form("passenger_login"):
    passenger_name = st.text_input("Passenger Name")
    booking_id = st.text_input(
        "Booking ID",
        placeholder="Example: SS1025"
    )

    login_button = st.form_submit_button(
        "Login",
        use_container_width=True
    )

if login_button:
    if passenger_name.strip() and booking_id.strip():
        st.session_state["passenger_name"] = passenger_name.strip()
        st.session_state["booking_id"] = booking_id.strip()
        st.session_state["passenger_logged_in"] = True

        st.success(f"Welcome, {passenger_name}!")
        st.info("Passenger Dashboard will be added in the next step.")
    else:
        st.error("Please enter your name and booking ID.")