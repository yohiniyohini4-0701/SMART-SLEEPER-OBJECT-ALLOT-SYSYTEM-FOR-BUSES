import streamlit as st
import streamlit.components.v1 as components
from pathlib import Path
import html
import re
import requests

# ==================================================
# PAGE CONFIGURATION
# ==================================================

st.set_page_config(
    page_title="SMART SLEEPER",
    page_icon="🚌",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ==================================================
# LOAD CSS
# ==================================================

css_file = Path(__file__).parent / "style.css"

if css_file.exists():
    st.markdown(
        f"<style>{css_file.read_text(encoding='utf-8')}</style>",
        unsafe_allow_html=True
    )

# ==================================================
# SESSION STATE
# ==================================================

defaults = {
    "page": "home",
    "passenger": {},
    "missing_alerts": [],
    "destination_alert": False,
    "saved_journey": False,
    "journeys": {},
    "staff": {},
    "staff_alert_status": {},
    "alert_statuses": {},
    "staff_section": "Dashboard",
    "staff_access": {},
    "admin_section": "Overview",
}

for key, value in defaults.items():
    if key not in st.session_state:
        st.session_state[key] = value


def safe(value):
    """Escape user-entered text before placing it in HTML."""
    return html.escape(str(value))


def header():
    st.markdown(
        """
        <div class="brand">
            <div class="brand-icon">🚌</div>
            <div class="brand-name">SMART <span>SLEEPER</span></div>
            <div class="brand-caption">
                SMART TRAVEL • SAFER JOURNEYS
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )


def back_home():
    if st.button("← Back to Home", use_container_width=True):
        st.session_state.page = "home"
        st.rerun()


def valid_phone(number):
    return bool(re.fullmatch(r"[0-9]{10}", number.strip()))


# ==================================================
# HOME PAGE
# ==================================================

if st.session_state.page == "home":

    header()

    st.markdown(
        """
        <div class="hero">
            <div class="hero-badge">✦ INTELLIGENT BUS SAFETY ✦</div>
            <h1>SMART SLEEPER</h1>
            <p>
                Your journey, your belongings,<br>
                your safety — all in one place.
            </p>
            <div class="home-label">SELECT YOUR PORTAL</div>
        </div>
        """,
        unsafe_allow_html=True
    )

    with st.container(border=True):
        st.markdown(
            """
            <div class="role-card">
                <div class="role-icon passenger-icon">🎒</div>
                <div class="role-number">01 / PASSENGER</div>
                <h3>Passenger Portal</h3>
                <p>
                    Register your journey, belongings, contact numbers,
                    and alert preferences.
                </p>
                <div class="tag-row">
                    <span>OBJECT ALERTS</span>
                    <span>GPS SUPPORT</span>
                    <span>DESTINATION ALERTS</span>
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

        if st.button(
            "Continue as Passenger →",
            key="passenger_portal",
            use_container_width=True
        ):
            st.session_state.page = "passenger_login"
            st.rerun()

    with st.container(border=True):
        st.markdown(
            """
            <div class="role-card">
                <div class="role-icon staff-icon">🧑‍✈️</div>
                <div class="role-number">02 / STAFF</div>
                <h3>Staff Portal</h3>
                <p>
                    A dedicated portal for bus staff to assist passengers
                    and review alerts.
                </p>
                <div class="tag-row">
                    <span>PASSENGER SUPPORT</span>
                    <span>ALERT REVIEW</span>
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

        if st.button(
            "Continue as Staff →",
            key="staff_portal",
            use_container_width=True
        ):
            st.session_state.page = "staff_login"
            st.rerun()

    with st.container(border=True):
        st.markdown(
            """
            <div class="role-card">
                <div class="role-icon admin-icon">🛡️</div>
                <div class="role-number">03 / ADMIN</div>
                <h3>Admin Portal</h3>
                <p>
                    A dedicated portal for system administration
                    and monitoring.
                </p>
                <div class="tag-row">
                    <span>MANAGEMENT</span>
                    <span>SYSTEM MONITORING</span>
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

        if st.button(
            "Continue as Admin →",
            key="admin_portal",
            use_container_width=True
        ):
            st.session_state.page = "admin_login"
            st.rerun()

    st.markdown(
        """
        <div class="footer">
            SMART SLEEPER © 2026<br>
            <span>Travel smarter. Travel safer.</span>
        </div>
        """,
        unsafe_allow_html=True
    )


# ==================================================
# PASSENGER LOGIN
# ==================================================

elif st.session_state.page == "passenger_login":

    header()

    st.markdown(
        """
        <div class="page-heading">
            <div class="section-label">PASSENGER ACCESS</div>
            <h1>Passenger Login 🎒</h1>
            <p>Enter your name and booking ID to continue.</p>
        </div>
        """,
        unsafe_allow_html=True
    )

    with st.container(border=True):

        with st.form("passenger_login_form"):

            name = st.text_input(
                "Passenger Name",
                placeholder="Enter your full name"
            )

            booking_id = st.text_input(
                "Booking ID",
                placeholder="Example: SS1025"
            )

            submitted = st.form_submit_button(
                "Continue to My Journey →",
                use_container_width=True
            )

            if submitted:

                if not name.strip():
                    st.error("Please enter your passenger name.")

                elif not booking_id.strip():
                    st.error("Please enter your booking ID.")

                else:
                    st.session_state.passenger = {
                        "name": name.strip(),
                        "booking_id": booking_id.strip().upper()
                    }

                    st.session_state.saved_journey = False
                    st.session_state.missing_alerts = []
                    st.session_state.destination_alert = False
                    st.session_state.page = "passenger_dashboard"
                    st.rerun()

    back_home()


# ==================================================
# PASSENGER DASHBOARD
# ==================================================

elif st.session_state.page == "passenger_dashboard":

    header()

    passenger = st.session_state.passenger

    st.markdown(
        f"""
        <div class="welcome-card">
            <div class="section-label">YOUR PERSONAL TRAVEL SPACE</div>
            <h1>Hi, {safe(passenger.get("name", "Passenger"))} 👋</h1>
            <p>
                Booking ID:
                <strong>{safe(passenger.get("booking_id", ""))}</strong>
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )

    # --------------------------------------------------
    # JOURNEY DETAILS
    # --------------------------------------------------

    st.markdown(
        '<div class="section-title">🚌 Journey Details</div>',
        unsafe_allow_html=True
    )

    with st.container(border=True):

        bus_number = st.text_input(
            "Bus Number",
            placeholder="Example: TN 45 AB 1234",
            key="bus_number"
        )

        seat_number = st.text_input(
            "Seat / Berth Number",
            placeholder="Example: L1, U2, B5",
            key="seat_number"
        )

        boarding_point = st.text_input(
            "Boarding Point",
            placeholder="Where will you board?",
            key="boarding_point"
        )

        destination = st.text_input(
            "Destination",
            placeholder="Where will you get down?",
            key="destination"
        )

    # --------------------------------------------------
    # OBJECT REGISTRATION
    # Maximum 10 objects in total.
    # All objects marked as bringing are tracked.
    # --------------------------------------------------

    st.markdown(
        '<div class="section-title">🎒 Objects You Are Bringing</div>',
        unsafe_allow_html=True
    )

    st.info(
        "Select the objects you are actually carrying. "
        "You can also add your own object names. "
        "A maximum of 10 objects is allowed in total."
    )

    predefined_objects = [
        "Mobile Phone",
        "Laptop",
        "Handbag",
        "Suitcase",
        "Backpack",
        "Water Bottle",
        "Headphones",
        "Wallet",
        "Charger",
        "Smartwatch",
        "Power Bank",
        "Umbrella",
        "Camera",
        "Medicine Bag",
        "Other"
    ]

    with st.container(border=True):

        selected_predefined = st.multiselect(
            "Choose from the available objects",
            options=predefined_objects,
            help="Select only objects you are bringing.",
            key="predefined_objects"
        )

        custom_objects_text = st.text_area(
            "Add your own objects",
            placeholder=(
                "Enter one object per line.\n"
                "Example:\n"
                "Umbrella\n"
                "Power Bank\n"
                "Smart Watch"
            ),
            height=110,
            key="custom_objects"
        )

        st.caption(
            "You can select predefined objects and type additional "
            "objects. Duplicate names will be removed."
        )

    # Build combined object list.
    # Ignore the 'Other' placeholder until a name is typed.

    custom_objects = [
        item.strip()
        for item in custom_objects_text.splitlines()
        if item.strip()
    ]

    registered_objects = [
        item for item in selected_predefined
        if item != "Other"
    ]

    for custom_item in custom_objects:
        if custom_item.casefold() not in {
            item.casefold() for item in registered_objects
        }:
            registered_objects.append(custom_item)

    # Show the actual total.
    st.markdown(
        f"""
        <div class="object-counter">
            REGISTERED OBJECTS
            <strong>{len(registered_objects)} / 10</strong>
        </div>
        """,
        unsafe_allow_html=True
    )

    if len(registered_objects) > 10:
        st.error(
            "You have entered more than 10 objects. "
            "Please remove some objects before saving."
        )

    elif registered_objects:

        st.markdown("**Objects selected for tracking:**")

        for item in registered_objects:
            st.markdown(
                f"""
                <div class="object-item">
                    <span>🎒</span>
                    <span>{safe(item)}</span>
                    <span class="tracking-badge">TRACKING ENABLED</span>
                </div>
                """,
                unsafe_allow_html=True
            )

        st.caption(
            "All registered objects are included in the alert list."
        )

    else:
        st.caption(
            "No objects selected yet. Add at least one object to continue."
        )

    # --------------------------------------------------
    # CONTACT NUMBERS
    # --------------------------------------------------

    st.markdown(
        '<div class="section-title">📱 Emergency Contact Details</div>',
        unsafe_allow_html=True
    )

    with st.container(border=True):

        primary_phone = st.text_input(
            "Primary Contact Number",
            placeholder="Enter 10-digit mobile number",
            max_chars=10,
            key="primary_phone"
        )

        alternative_phone_1 = st.text_input(
            "Alternative Contact Number 1 (Optional)",
            placeholder="Enter 10-digit mobile number",
            max_chars=10,
            key="alternative_phone_1"
        )

        alternative_phone_2 = st.text_input(
            "Alternative Contact Number 2 (Optional)",
            placeholder="Enter 10-digit mobile number",
            max_chars=10,
            key="alternative_phone_2"
        )

    # --------------------------------------------------
    # GPS
    # --------------------------------------------------

    st.markdown(
        '<div class="section-title">📍 GPS & Location</div>',
        unsafe_allow_html=True
    )

    gps_enabled = st.toggle(
        "Enable GPS location",
        value=False,
        key="gps_enabled"
    )

    if gps_enabled:

        st.info(
            "Allow location permission in your browser to get "
            "your current location."
        )

        components.html(
            """
            <div class="gps-panel">
                <strong>📍 Current GPS Location</strong>
                <p id="gps-status">Location has not been requested.</p>
                <p id="gps-result"></p>

                <button onclick="getLocation()">
                    Get Current Location
                </button>
            </div>

            <script>
            function getLocation() {
                const status = document.getElementById("gps-status");
                const result = document.getElementById("gps-result");

                if (!navigator.geolocation) {
                    status.innerText =
                        "Location is not supported by this browser.";
                    return;
                }

                status.innerText = "Requesting location permission...";

                navigator.geolocation.getCurrentPosition(
                    function(position) {
                        status.innerText = "Location received.";

                        result.innerText =
                            "Latitude: " +
                            position.coords.latitude.toFixed(6) +
                            " | Longitude: " +
                            position.coords.longitude.toFixed(6);
                    },
                    function(error) {
                        status.innerText =
                            "Location unavailable. Please check permissions.";
                        result.innerText = error.message;
                    },
                    {
                        enableHighAccuracy: true,
                        timeout: 10000
                    }
                );
            }
            </script>
            """,
            height=180
        )

        st.caption(
            "This GPS preview displays coordinates in the browser panel. "
            "It does not yet send the location to the dashboard or "
            "continuously track the bus."
        )

    else:
        st.caption("GPS is disabled.")

    # --------------------------------------------------
    # ALERT PREFERENCES
    # --------------------------------------------------

    st.markdown(
        '<div class="section-title">🔔 Alert Preferences</div>',
        unsafe_allow_html=True
    )

    with st.container(border=True):

        object_alerts_enabled = st.checkbox(
            "🎒 Enable Missing Object Alerts",
            value=True,
            key="object_alerts_enabled"
        )

        destination_alerts_enabled = st.checkbox(
            "🚌 Enable Destination Arrival Alerts",
            value=True,
            key="destination_alerts_enabled"
        )

        st.caption(
            "Automatic detection requires sensor integration "
            "and GPS-based journey logic."
        )

    # --------------------------------------------------
    # SAVE JOURNEY
    # --------------------------------------------------

    st.markdown(
        '<div class="section-title">💾 Save Your Journey</div>',
        unsafe_allow_html=True
    )

    if st.button(
        "Save Journey & Alert Settings",
        use_container_width=True,
        key="save_journey"
    ):

        errors = []

        if not bus_number.strip():
            errors.append("Enter your bus number.")

        if not seat_number.strip():
            errors.append("Enter your seat or berth number.")

        if not boarding_point.strip():
            errors.append("Enter your boarding point.")

        if not destination.strip():
            errors.append("Enter your destination.")

        if not registered_objects:
            errors.append("Register at least one object.")

        if len(registered_objects) > 10:
            errors.append("Register no more than 10 objects.")

        if not valid_phone(primary_phone):
            errors.append(
                "Enter a valid 10-digit primary contact number."
            )

        for label, number in [
            ("Alternative Contact 1", alternative_phone_1),
            ("Alternative Contact 2", alternative_phone_2)
        ]:
            if number.strip() and not valid_phone(number):
                errors.append(
                    f"{label} must contain exactly 10 digits."
                )

        if errors:
            for error in errors:
                st.error(error)

        else:

            passenger.update({
                "bus_number": bus_number.strip(),
                "seat_number": seat_number.strip(),
                "boarding_point": boarding_point.strip(),
                "destination": destination.strip(),
                "objects": registered_objects.copy(),
                "primary_phone": primary_phone.strip(),
                "alternative_phone_1": alternative_phone_1.strip(),
                "alternative_phone_2": alternative_phone_2.strip(),
                "gps_enabled": gps_enabled,
                "object_alerts_enabled": object_alerts_enabled,
                "destination_alerts_enabled": destination_alerts_enabled
            })

            st.session_state.passenger = passenger
            st.session_state.saved_journey = True
            # Keep the latest saved journey available to the staff dashboard
            # during this running app session. A database will be connected later.
            st.session_state.journeys[passenger.get("booking_id", "UNKNOWN")] = passenger.copy()
            try:
                response = requests.post(
                    "http://localhost:8080/api/passengers",
                    json={
                        "passengerName": passenger.get("name", ""),
                        "bookingId": passenger.get("booking_id", ""),
                        "destination": passenger.get("destination", "")
                    },
                    timeout=5
                )
                response.raise_for_status()
                st.success("Journey details saved and sent to the database!")

            except requests.RequestException:
                st.error(
                    "Journey saved in this app, but database connection failed. "
                    "Please check whether the Java backend is running."
                )
    # --------------------------------------------------
    # ALERT CENTRE
    # --------------------------------------------------

    st.markdown(
        '<div class="section-title">🔔 My Alert Centre</div>',
        unsafe_allow_html=True
    )

    saved_data = st.session_state.passenger

    with st.container(border=True):

        st.markdown("### 🎒 Missing Object Alerts")

        saved_objects = saved_data.get("objects", [])

        if not saved_data.get("object_alerts_enabled", True):

            st.info("Missing object alerts are disabled.")

        elif not saved_objects:

            st.caption(
                "Register your objects and save your journey to use alerts."
            )

        else:

            object_to_test = st.selectbox(
                "Choose a registered object to test an alert",
                options=saved_objects,
                key="object_to_test"
            )

            if st.button(
                "Test Missing Object Alert",
                key="test_missing_alert"
            ):

                message = (
                    f"Test alert: Please check your belongings. "
                    f"'{object_to_test}' has been marked as missing."
                )

                st.session_state.missing_alerts.append(message)

            for alert in st.session_state.missing_alerts:
                st.warning(f"⚠️ {alert}")

            st.caption(
                "These are test alerts. Automatic missing-object detection "
                "requires suitable hardware or tracking integration."
            )

        st.markdown("---")

        st.markdown("### 🚌 Destination Arrival Alerts")

        saved_destination = saved_data.get("destination", "")

        if not saved_data.get("destination_alerts_enabled", True):

            st.info("Destination alerts are disabled.")

        elif not saved_destination:

            st.caption(
                "Save your journey details to test a destination reminder."
            )

        else:

            st.write(
                f"Registered destination: **{saved_destination}**"
            )

            if st.button(
                "Test Destination Reminder",
                key="test_destination_alert"
            ):
                st.session_state.destination_alert = True

            if st.session_state.destination_alert:
                st.success(
                    f"Destination reminder: You are travelling to "
                    f"{saved_destination}. Please prepare to get down."
                )

            st.caption(
                "Automatic arrival alerts will require a working GPS "
                "tracking and destination-distance calculation system."
            )

    # --------------------------------------------------
    # JOURNEY SUMMARY
    # --------------------------------------------------

    if st.session_state.saved_journey:

        st.markdown(
            '<div class="section-title">📋 Journey Summary</div>',
            unsafe_allow_html=True
        )

        with st.container(border=True):

            st.write("**Passenger:**", passenger.get("name", ""))
            st.write("**Booking ID:**", passenger.get("booking_id", ""))
            st.write("**Bus Number:**", passenger.get("bus_number", ""))
            st.write("**Seat / Berth:**", passenger.get("seat_number", ""))
            st.write("**Boarding Point:**", passenger.get("boarding_point", ""))
            st.write("**Destination:**", passenger.get("destination", ""))
            st.write("**Primary Contact:**", passenger.get("primary_phone", ""))

            st.write("**Registered Objects:**")

            for item in passenger.get("objects", []):
                st.write(f"• {item}")

            st.write(
                "**GPS Setting:**",
                "Enabled" if passenger.get("gps_enabled") else "Disabled"
            )

    st.markdown(
        """
        <div class="footer">
            SMART SLEEPER<br>
            <span>Your journey matters.</span>
        </div>
        """,
        unsafe_allow_html=True
    )

    if st.button("Log Out", key="passenger_logout"):
        st.session_state.page = "home"
        st.rerun()


# ==================================================
# STAFF LOGIN — BASIC FOR NOW
# ==================================================

elif st.session_state.page == "staff_login":

    header()

    st.markdown(
        """
        <div class="page-heading">
            <div class="section-label">BUS STAFF ACCESS</div>
            <h1>Staff Login 🧑‍✈️</h1>
            <p>Enter your staff details.</p>
        </div>
        """,
        unsafe_allow_html=True
    )

    with st.container(border=True):

        with st.form("staff_login_form"):

            staff_name = st.text_input("Staff Name")
            staff_id = st.text_input("Staff ID")
            staff_password = st.text_input(
                "Password",
                type="password"
            )

            submitted = st.form_submit_button(
                "Continue to Staff Portal",
                use_container_width=True
            )

            if submitted:

                entered_staff_id = staff_id.strip().upper()
                access_list = st.session_state.get("staff_access", {})
                if staff_name.strip() and entered_staff_id and staff_password:
                    if access_list and not access_list.get(entered_staff_id, {}).get("enabled", False):
                        st.error("Access not enabled for this Staff ID. Please contact Admin.")
                    else:
                        bus_assignments = {
                            "ST101": "TN 45 AB 1234",
                            "ST102": "TN 38 CD 5678",
                            "ST103": "TN 47 EF 9012",
                        }
                        managed = access_list.get(entered_staff_id, {})
                        st.session_state.staff = {
                            "name": staff_name.strip(),
                            "staff_id": entered_staff_id,
                            "assigned_bus": managed.get("assigned_bus", bus_assignments.get(entered_staff_id, "TN 45 AB 1234"))
                        }
                        st.session_state.staff_section = "Dashboard"
                        st.session_state.page = "staff_dashboard"
                        st.rerun()
                else:
                    st.error("Please complete all fields.")

    back_home()


elif st.session_state.page == "staff_dashboard":

    st.markdown("<div class='app-topline'>SMART SLEEPER <span>STAFF OPERATIONS</span></div>", unsafe_allow_html=True)
    st.sidebar.markdown("## 🚌 SMART SLEEPER")
    st.sidebar.caption("STAFF OPERATIONS PORTAL")
    st.sidebar.markdown("---")
    staff_view = st.sidebar.radio(
        "NAVIGATION",
        ["Overview", "Passengers & Destinations", "Alerts Centre", "Alert History", "My Profile"],
        key="staff_nav"
    )
    st.sidebar.markdown("---")
    staff_profile = st.session_state.get("staff", {})
    staff_name_display = staff_profile.get("name", "Bus Staff")
    staff_id_display = staff_profile.get("staff_id", "Not entered")
    staff_bus_display = staff_profile.get("assigned_bus", "Not assigned")
    st.sidebar.markdown(f"**Signed in as**  \n{safe(staff_name_display)}")
    st.sidebar.markdown(f"**Assigned bus**  \n🚌 {safe(staff_bus_display)}")
    if st.sidebar.button("Log Out", use_container_width=True, key="staff_sidebar_logout"):
        st.session_state.page = "home"
        st.rerun()

    journey_store = st.session_state.get("journeys", {})
    records = [r.copy() for r in journey_store.values()
               if str(r.get("bus_number", "")).strip().casefold() == str(staff_bus_display).strip().casefold()]
    # Include the current passenger if journey was saved in this session.
    if st.session_state.saved_journey and st.session_state.passenger:
        current = st.session_state.passenger.copy()
        if str(current.get("bus_number", "")).strip().casefold() == str(staff_bus_display).strip().casefold() and not any(r.get("booking_id") == current.get("booking_id") for r in records):
            records.append(current)

    st.markdown(f"<div class='dashboard-hero'><div class='eyebrow'>BUS OPERATIONS / STAFF PORTAL</div><h1>{staff_view}</h1><p>Monitor passenger journeys and review alerts for your assigned bus.</p><div class='bus-chip'>🚌 Assigned Bus: {safe(staff_bus_display)}</div></div>", unsafe_allow_html=True)

    if staff_view == "Overview":
        alerts = []
        for r in records:
            for msg in r.get("missing_alerts", []):
                alerts.append((r, msg, "Object alert"))
        c1, c2, c3 = st.columns(3)
        c1.metric("Passengers on this bus", len(records))
        c2.metric("Registered destinations", len({r.get('destination','') for r in records if r.get('destination')}))
        c3.metric("GPS enabled", sum(bool(r.get('gps_enabled')) for r in records))
        st.markdown("### 📍 Passenger destination overview")
        if records:
            for r in records:
                with st.container(border=True):
                    a,b,c,d = st.columns([2,1,2,2])
                    a.markdown(f"**{safe(r.get('name','Passenger'))}**  \nBooking: `{safe(r.get('booking_id',''))}`")
                    b.markdown(f"**Berth**  \n{safe(r.get('seat_number','—'))}")
                    c.markdown(f"**Boarding**  \n{safe(r.get('boarding_point','—'))}")
                    d.markdown(f"**Getting down**  \n📍 {safe(r.get('destination','—'))}")
        else:
            st.info("No saved passenger journeys match this bus yet. Ask passengers to register and save their journey using the same bus number.")
        st.caption("Prototype note: this view uses journeys saved in the current Streamlit session. Database sharing between separate passenger/staff sessions will be added later.")

    elif staff_view == "Passengers & Destinations":
        st.markdown("### 👥 Passenger manifest")
        st.write("Passenger count and each passenger's boarding and drop-off point for the assigned bus.")
        if records:
            rows = [{"Passenger Name": r.get("name", ""), "Booking ID": r.get("booking_id", ""), "Berth": r.get("seat_number", ""), "Boarding Point": r.get("boarding_point", ""), "Destination / Drop-off": r.get("destination", ""), "GPS": "Enabled" if r.get("gps_enabled") else "Off"} for r in records]
            st.dataframe(rows, use_container_width=True, hide_index=True)
            st.success(f"Showing {len(records)} passenger journey(s) for {staff_bus_display}.")
        else:
            st.info("No matching passengers yet. Passenger and staff bus numbers must match exactly.")
        with st.expander("How to test this page"):
            st.markdown("1. Open Passenger Portal in the same app session.\n2. Register journey details.\n3. Enter the assigned bus number shown in this sidebar.\n4. Save Journey.\n5. Return to Staff Portal to view the passenger.")

    elif staff_view == "Alerts Centre":
        st.markdown("### 🔔 Alerts requiring attention")
        any_alerts = False
        for r in records:
            for msg in r.get("missing_alerts", []):
                any_alerts = True
                alert_key = f"{r.get('booking_id')}|{msg}"
                status = st.session_state.alert_statuses.get(alert_key, "New")
                with st.container(border=True):
                    st.markdown(f"**🎒 Object alert** — {safe(r.get('name','Passenger'))} (`{safe(r.get('booking_id',''))}`)")
                    st.write(msg)
                    new_status = st.selectbox("Alert status", ["New", "Checking", "Resolved"], index=["New", "Checking", "Resolved"].index(status), key=f"status_{abs(hash(alert_key))}")
                    st.session_state.alert_statuses[alert_key] = new_status
        if not any_alerts:
            st.info("No passenger object alerts are available for this bus. Test alerts from a passenger account will appear after database/session sharing is implemented.")
        st.markdown("### 🚌 Destination reminders")
        dest_records = [r for r in records if r.get("destination")]
        if dest_records:
            for r in dest_records:
                st.markdown(f"- **{safe(r.get('name','Passenger'))}** — berth {safe(r.get('seat_number','—'))} → **{safe(r.get('destination',''))}**")
        else:
            st.caption("No destinations have been registered yet.")
        st.caption("Alerts shown here are prototype records; automatic sensor/GPS alerts are not connected yet.")

    elif staff_view == "Alert History":
        st.markdown("### 🗂️ Alert history")
        history = []
        for r in records:
            for msg in r.get("missing_alerts", []):
                key = f"{r.get('booking_id')}|{msg}"
                history.append({"Passenger": r.get("name", ""), "Booking ID": r.get("booking_id", ""), "Alert": msg, "Status": st.session_state.alert_statuses.get(key, "New")})
        if history:
            st.dataframe(history, use_container_width=True, hide_index=True)
        else:
            st.info("No alerts recorded for this bus yet.")

    elif staff_view == "My Profile":
        st.markdown("### 🪪 Staff profile")
        with st.container(border=True):
            st.write("**Staff name:**", staff_name_display)
            st.write("**Staff ID:**", staff_id_display)
            st.write("**Assigned bus:**", staff_bus_display)
            st.write("**Access level:**", "Bus Staff")
        st.warning("Demo mode: bus assignments are sample mappings. Admin-managed assignments and secure authentication will be connected with the database later.")


# ==================================================
# ADMIN LOGIN — BASIC FOR NOW
# ==================================================

elif st.session_state.page == "admin_login":

    header()

    st.markdown(
        """
        <div class="page-heading">
            <div class="section-label">SYSTEM MANAGEMENT</div>
            <h1>Admin Login 🛡️</h1>
            <p>Enter your administrator details.</p>
        </div>
        """,
        unsafe_allow_html=True
    )

    with st.container(border=True):

        with st.form("admin_login_form"):

            username = st.text_input("Admin Username")
            password = st.text_input(
                "Admin Password",
                type="password"
            )

            submitted = st.form_submit_button(
                "Continue to Admin Portal",
                use_container_width=True
            )

            if submitted:

                if username.strip() and password:
                    st.session_state.page = "admin_dashboard"
                    st.rerun()
                else:
                    st.error("Please complete all fields.")

    back_home()


elif st.session_state.page == "admin_dashboard":

    st.markdown("<div class='app-topline'>SMART SLEEPER <span>ADMIN CONTROL CENTRE</span></div>", unsafe_allow_html=True)
    st.sidebar.markdown("## 🛡️ SMART SLEEPER")
    st.sidebar.caption("Admin control centre")
    admin_view = st.sidebar.radio("ADMIN MENU", ["Overview & Reports", "Staff Access", "Passenger & Journey Reports", "Alert Analysis", "System Notes"], key="admin_nav")
    st.sidebar.divider()
    st.sidebar.markdown("**Admin account**  \nAdministrator")
    if st.sidebar.button("Log Out", use_container_width=True, key="admin_sidebar_logout"):
        st.session_state.page = "home"
        st.rerun()

    journeys = list(st.session_state.get("journeys", {}).values())
    staff_access = st.session_state.get("staff_access", {})
    missing_alerts = st.session_state.get("missing_alerts", [])
    total_journeys = len(journeys)
    unique_buses = len({str(j.get("bus_number", "")).strip() for j in journeys if str(j.get("bus_number", "")).strip()})
    enabled_staff = sum(1 for item in staff_access.values() if item.get("enabled", False))
    st.markdown(f"<div class='dashboard-hero'><div class='eyebrow'>ADMINISTRATION / REPORTS & ACCESS</div><h1>{safe(admin_view)} 🛡️</h1><p>Review overall journey information, analyse alerts, and control staff portal access.</p></div>", unsafe_allow_html=True)

    if admin_view == "Overview & Reports":
        st.markdown("### 📊 Overall System Snapshot")
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Saved Journeys", total_journeys)
        c2.metric("Buses in Journey Records", unique_buses)
        c3.metric("Staff Access Entries", len(staff_access))
        c4.metric("Enabled Staff", enabled_staff)
        c5, c6, c7 = st.columns(3)
        c5.metric("Missing-object Test Alerts", len(missing_alerts))
        c6.metric("Journey Records", total_journeys)
        c7.metric("Object Alerts Enabled", sum(1 for j in journeys if j.get("object_alerts_enabled")))
        st.info("These reports use data saved in this running app session. A shared database is not connected yet; data may reset when the app restarts.")
        st.markdown("### 🚌 Recent Journey Records")
        if journeys:
            import pandas as pd
            rows = [{"Passenger": j.get("name", "—"), "Booking ID": j.get("booking_id", "—"), "Bus Number": j.get("bus_number", "—"), "Berth": j.get("berth", j.get("seat_berth", "—")), "Boarding Point": j.get("boarding_point", "—"), "Destination": j.get("destination", "—"), "GPS Enabled": "Yes" if j.get("gps_enabled") else "No"} for j in journeys]
            df = pd.DataFrame(rows)
            st.dataframe(df, use_container_width=True, hide_index=True)
            st.download_button("⬇️ Download Journey Report (CSV)", df.to_csv(index=False).encode("utf-8"), file_name="smart_sleeper_journey_report.csv", mime="text/csv")
        else:
            st.info("No saved journeys yet. Save a journey from Passenger Portal to populate reports.")

    elif admin_view == "Staff Access":
        st.markdown("### 🔐 Grant or Revoke Staff Portal Access")
        st.caption("Add staff details and assigned bus. You can enable or disable access later.")
        with st.form("admin_add_staff_form", clear_on_submit=True):
            c1, c2 = st.columns(2)
            new_id = c1.text_input("Staff ID", placeholder="e.g. ST104").strip().upper()
            new_name = c2.text_input("Staff Name", placeholder="e.g. Kumar").strip()
            new_bus = st.text_input("Assigned Bus Number", placeholder="e.g. TN 45 AB 1234").strip().upper()
            add = st.form_submit_button("➕ Save Staff & Enable Access", use_container_width=True)
            if add:
                if not new_id or not new_name or not new_bus:
                    st.error("Please fill all three fields.")
                else:
                    st.session_state.staff_access[new_id] = {"name": new_name, "assigned_bus": new_bus, "enabled": True}
                    st.success(f"Access enabled for {new_name} ({new_id}).")
                    st.rerun()
        if staff_access:
            import pandas as pd
            staff_df = pd.DataFrame([{"Staff ID": sid, "Name": d.get("name", "—"), "Assigned Bus": d.get("assigned_bus", "—"), "Access": "Enabled" if d.get("enabled") else "Disabled"} for sid, d in sorted(staff_access.items())])
            st.dataframe(staff_df, use_container_width=True, hide_index=True)
            selected = st.selectbox("Select Staff ID", sorted(staff_access.keys()), key="admin_selected_staff")
            left, right = st.columns(2)
            if left.button("✅ Enable Access", use_container_width=True):
                st.session_state.staff_access[selected]["enabled"] = True
                st.rerun()
            if right.button("🚫 Disable Access", use_container_width=True):
                st.session_state.staff_access[selected]["enabled"] = False
                st.rerun()
        else:
            st.info("No staff access entries yet. Add a staff member above. Existing demo staff IDs work until the first managed staff entry is created.")

    elif admin_view == "Passenger & Journey Reports":
        st.markdown("### 👥 Passenger & Journey Analysis")
        if journeys:
            import pandas as pd
            df = pd.DataFrame([{"Passenger": j.get("name", "—"), "Booking ID": j.get("booking_id", "—"), "Bus": j.get("bus_number", "—"), "Berth": j.get("berth", j.get("seat_berth", "—")), "From": j.get("boarding_point", "—"), "To": j.get("destination", "—"), "GPS Enabled": bool(j.get("gps_enabled")), "Object Alerts Enabled": bool(j.get("object_alerts_enabled")), "Destination Alerts Enabled": bool(j.get("destination_alerts_enabled"))} for j in journeys])
            query = st.text_input("Search by passenger name, booking ID, bus or destination")
            if query:
                df = df[df.apply(lambda row: query.casefold() in " ".join(map(str, row.values)).casefold(), axis=1)]
            st.dataframe(df, use_container_width=True, hide_index=True)
            st.download_button("⬇️ Export Passenger Report (CSV)", df.to_csv(index=False).encode("utf-8"), file_name="smart_sleeper_passenger_report.csv", mime="text/csv")
        else:
            st.info("No journey records yet. Save a journey from Passenger Portal first.")

    elif admin_view == "Alert Analysis":
        st.markdown("### 🚨 Alert Summary & Analysis")
        a, b, c = st.columns(3)
        a.metric("Missing-object test alerts", len(missing_alerts))
        b.metric("Journeys with object alerts enabled", sum(1 for j in journeys if j.get("object_alerts_enabled")))
        c.metric("Journeys with destination alerts enabled", sum(1 for j in journeys if j.get("destination_alerts_enabled")))
        if missing_alerts:
            for i, alert in enumerate(missing_alerts, start=1):
                st.warning(f"{i}. {alert}")
        else:
            st.info("No missing-object test alerts recorded in this session yet.")
        st.caption("Alerts shown here are test/session alerts. Automatic sensor detection and persistent alert history are not connected yet.")

    elif admin_view == "System Notes":
        st.markdown("### ℹ️ Integration Status")
        st.markdown("- Passenger journey form: available.\n- Staff portal: available with prototype sign-in.\n- Admin reports: use session journey and alert records.\n- Staff access: managed from the Staff Access page.\n- Shared database, secure password verification, real-time GPS, and hardware-based object detection: not connected yet.")
        st.warning("Prototype only: do not use it yet for real passenger personal data or real security decisions.")
