import pandas as pd

file_path = "dataset/bus_gps_data.csv"

df = pd.read_csv(file_path)

print("Dataset loaded successfully!")
print("\nFirst 5 rows:")
print(df.head())

print("\nDataset information:")
print(df.info())